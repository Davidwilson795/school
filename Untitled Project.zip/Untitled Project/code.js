onEvent("picker", "click", function( ) {
  var x = randomNumber(1, 8);
  if (x==1) {
    setScreen("screen2");
  } else if ((x==2)) {
    setScreen("screen3");
  } else if (x==3) {
    setScreen("screen4");
  } else if (x==4) {
    setScreen("screen5");
  } else if (x==5) {
    setScreen("screen6");
  } else if (x==6) {
    setScreen("screen7");
  } else if (x==7) {
    setScreen("screen8");
  } else if (x==8) {
    setScreen("screen9");
  }
});
onEvent("button2", "click", function( ) {
  setScreen("screen1");
});
onEvent("button3", "click", function( ) {
  setScreen("screen1");
});
onEvent("button1", "click", function( ) {
  setScreen("screen1");
});
onEvent("button4", "click", function( ) {
  setScreen("screen1");
});
onEvent("button5", "click", function( ) {
  setScreen("screen1");
});
onEvent("button6", "click", function( ) {
  setScreen("screen1");
});
onEvent("button7", "click", function( ) {
  setScreen("screen1");
});
onEvent("button8", "click", function( ) {
  setScreen("screen1");
});
